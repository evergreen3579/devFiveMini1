package com.jeommechu.menu.lunch;

import com.jeommechu.menu.common.JDBCUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LunchDAO {

    // 데이터베이스 연결을 위한 메소드
    private Connection getConnection() throws SQLException {
        return JDBCUtil.getConnection();
    }

    // 새로운 점심 메뉴를 추가하는 메소드
    public void addLunch(LunchVO lunchVO) throws SQLException {
        String sql = "INSERT INTO lunch (menu) VALUES (?)";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            if (lunchVO.getMenu() != null) {
                stmt.setString(1, lunchVO.getMenu());
            } else {
                throw new IllegalArgumentException("Menu cannot be null");
            }
            stmt.executeUpdate();
        }
    }

    // 전체 점심 메뉴 정보를 조회하는 메소드
    public List<LunchVO> getAllLunches() throws SQLException {
        List<LunchVO> lunches = new ArrayList<>();
        String sql = "SELECT * FROM lunch";
        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String menu = rs.getString("menu");
                LunchVO lunchVO = new LunchVO(id, menu);
                lunches.add(lunchVO);
            }
        }
        return lunches;
    }

    // 모든 점심 메뉴 정보를 삭제하는 메소드
    public void deleteAllLunches() throws SQLException {
        String sql = "DELETE FROM lunch";
        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sql);
        }
    }
    
    public boolean isMenuExists(String menu) throws SQLException {
        String sql = "SELECT COUNT(*) FROM lunch WHERE menu = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, menu);
            try (ResultSet rs = stmt.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }
}
