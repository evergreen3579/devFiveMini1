package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

@WebServlet("/random-food")
public class FoodServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<String> foodList = Arrays.asList("Pizza", "Burger", "Sushi", "Pasta", "Salad");

        // 랜덤으로 음식을 선택
        Random random = new Random();
        String randomFood = foodList.get(random.nextInt(foodList.size()));

        // 확률 계산
        double probability = 100.0 / foodList.size();

        // 이미지의 상대 경로 설정
        String imageURL = request.getContextPath() + "/image/random.png";  // 경로를 맞춰주세요

        response.setContentType("text/html; charset=UTF-8");
        response.getWriter().println("<html>");
        response.getWriter().println("<head>");
        response.getWriter().println("<title>Random Food Picker</title>");
        response.getWriter().println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css'>");
        response.getWriter().println("<style>");
        response.getWriter().println("body {");
        response.getWriter().println("    background: linear-gradient(45deg, #fbc2eb, #a6c1ee);");
        response.getWriter().println("    font-family: 'Noto Sans KR', sans-serif;");
        response.getWriter().println("    color: #333;");
        response.getWriter().println("    text-align: center;");
        response.getWriter().println("    padding: 50px;");
        response.getWriter().println("}");
        response.getWriter().println(".container {");
        response.getWriter().println("    background-color: white;");
        response.getWriter().println("    padding: 20px;");
        response.getWriter().println("    border-radius: 15px;");
        response.getWriter().println("    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);");
        response.getWriter().println("    max-width: 400px;");
        response.getWriter().println("    margin: 0 auto;");
        response.getWriter().println("}");
        response.getWriter().println("h1 {");
        response.getWriter().println("    font-size: 24px;");
        response.getWriter().println("    margin-bottom: 20px;");
        response.getWriter().println("    color: #6d6875;");
        response.getWriter().println("}");
        response.getWriter().println(".image-container {");
        response.getWriter().println("    margin-bottom: 20px;");
        response.getWriter().println("}");
        response.getWriter().println(".food-list {");
        response.getWriter().println("    margin-bottom: 20px;");
        response.getWriter().println("}");
        response.getWriter().println(".food-list ul {");
        response.getWriter().println("    list-style-type: none;");
        response.getWriter().println("    padding: 0;");
        response.getWriter().println("}");
        response.getWriter().println(".food-list li {");
        response.getWriter().println("    font-size: 18px;");
        response.getWriter().println("    color: #495057;");
        response.getWriter().println("}");
        response.getWriter().println("button {");
        response.getWriter().println("    font-size: 16px;");
        response.getWriter().println("    padding: 10px 20px;");
        response.getWriter().println("    background-color: #6d6875;");
        response.getWriter().println("    color: white;");
        response.getWriter().println("    border: none;");
        response.getWriter().println("    border-radius: 5px;");
        response.getWriter().println("    cursor: pointer;");
        response.getWriter().println("    transition: background-color 0.3s;");
        response.getWriter().println("}");
        response.getWriter().println("button:hover {");
        response.getWriter().println("    background-color: #333;");
        response.getWriter().println("}");
        response.getWriter().println("#result {");
        response.getWriter().println("    margin-top: 20px;");
        response.getWriter().println("    font-size: 24px;");
        response.getWriter().println("    color: #6d6875;");
        response.getWriter().println("}");
        response.getWriter().println("#probability {");
        response.getWriter().println("    margin-top: 10px;");
        response.getWriter().println("    font-size: 18px;");
        response.getWriter().println("    color: #6d6875;");
        response.getWriter().println("}");
        response.getWriter().println("</style>");
        response.getWriter().println("</head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<div class='container'>");

        // 이미지 삽입
        response.getWriter().println("<div class='image-container'>");
        response.getWriter().println("<img src='" + imageURL + "' alt='Random Food Image' width='150'>");
        response.getWriter().println("</div>");

        // 제비뽑기 기능 및 UI
        response.getWriter().println("<h1>점심 메뉴 목록</h1>");
        response.getWriter().println("<div class='food-list'>");
        response.getWriter().println("<ul>");
        for (String food : foodList) {
            response.getWriter().println("<li>" + food + "</li>");
        }
        response.getWriter().println("</ul>");
        response.getWriter().println("</div>");

        response.getWriter().println("<button onclick=\"startDrawing()\">메뉴 뽑기 <i class='fas fa-dice'></i></button>");

        response.getWriter().println("<div id=\"result\">");
        response.getWriter().println("오늘의 메뉴: <span id=\"result-food\">" + randomFood + "</span>");
        response.getWriter().println("</div>");

        // 확률 출력 부분 추가
        response.getWriter().println("<div id=\"probability\">");
        response.getWriter().println("각 메뉴가 뽑힐 확률: " + String.format("%.2f", probability) + "%");
        response.getWriter().println("</div>");

        response.getWriter().println("</div>"); // container 끝

        // JavaScript 코드를 body 끝 부분에 배치하여 HTML 요소들이 로드된 후 실행되도록 함
        response.getWriter().println("<script>");
        response.getWriter().println("function startDrawing() {");
        response.getWriter().println("    const foods = [");
        for (String food : foodList) {
            response.getWriter().println("        \"" + food + "\",");
        }
        response.getWriter().println("    ];");

        response.getWriter().println("    const resultSpan = document.getElementById('result-food');");
        response.getWriter().println("    let index = 0;");
        response.getWriter().println("    const interval = setInterval(() => {");
        response.getWriter().println("        resultSpan.innerText = foods[index];");
        response.getWriter().println("        index = (index + 1) % foods.length;");
        response.getWriter().println("    }, 100);");

        response.getWriter().println("    setTimeout(() => {");
        response.getWriter().println("        clearInterval(interval);");
        response.getWriter().println("        const randomIndex = Math.floor(Math.random() * foods.length);");
        response.getWriter().println("        resultSpan.innerText = foods[randomIndex];");
        response.getWriter().println("    }, 3000);");
        response.getWriter().println("}");
        response.getWriter().println("</script>");

        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }
}
