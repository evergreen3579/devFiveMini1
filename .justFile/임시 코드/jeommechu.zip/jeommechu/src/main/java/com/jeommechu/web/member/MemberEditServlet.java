package com.jeommechu.web.member;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import com.jeommechu.menu.user.MemberDAO;
import com.jeommechu.menu.user.MemberVO;

@WebServlet("/memberEdit")
public class MemberEditServlet extends HttpServlet {

    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html;charset=UTF-8");
    	try {
            int id = Integer.parseInt(request.getParameter("id"));
            MemberVO member = memberDAO.getMember(id);
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            
            if (member != null) {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head><title>회원 수정</title></head>");
                out.println("<body>");
                out.println("<h1>회원 수정</h1>");
                out.println("<form action='memberEdit' method='post'>");
                out.println("<input type='hidden' name='id' value='" + member.getId() + "'/>");
                out.println("<label for='memberID'>회원 ID:</label>");
                out.println("<input type='text' id='memberID' name='memberID' value='" + member.getMemberID() + "' required/><br/>");
                out.println("<label for='memberPW'>비밀번호:</label>");
                out.println("<input type='text' id='memberPW' name='memberPW' value='" + member.getMemberPW() + "' required/><br/>");
                out.println("<label for='memberName'>회원 이름:</label>");
                out.println("<input type='text' id='memberName' name='memberName' value='" + member.getMemberName() + "' required/><br/>");
                out.println("<label for='role'>권한:</label>");
                out.println("<input type='text' id='role' name='role' value='" + member.getRole() + "' required/><br/>");
                out.println("<input type='submit' value='수정 완료'/>");
                out.println("</form>");
                out.println("<a href='memberList'>목록으로 돌아가기</a>");
                out.println("</body>");
                out.println("</html>");
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "회원 정보를 찾을 수 없습니다.");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String memberID = request.getParameter("memberID");
            String memberPW = request.getParameter("memberPW");
            String memberName = request.getParameter("memberName");
            String role = request.getParameter("role");

            MemberVO member = new MemberVO(id, memberID, memberPW, memberName, role);
            memberDAO.updateMember(member);
            response.sendRedirect("memberList");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Database error", e);
        }
    }
}
