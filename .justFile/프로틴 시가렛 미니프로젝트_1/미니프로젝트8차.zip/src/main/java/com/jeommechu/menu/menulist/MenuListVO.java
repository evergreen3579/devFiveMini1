package com.jeommechu.menu.menulist;

public class MenuListVO {
    private String num;
    private String name;
    private double allKcal;
    private double ohKcal;
    private double w;
    private double p;
    private double f;
    private double c;
    private double s;
    private double na;
    private double sf;

    // Getters and Setters
    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAllKcal() {
        return allKcal;
    }

    public void setAllKcal(double allKcal) {
        this.allKcal = allKcal;
    }

    public double getOhKcal() {
        return ohKcal;
    }

    public void setOhKcal(double ohKcal) {
        this.ohKcal = ohKcal;
    }

    public double getW() {
        return w;
    }

    public void setW(double w) {
        this.w = w;
    }

    public double getP() {
        return p;
    }

    public void setP(double p) {
        this.p = p;
    }

    public double getF() {
        return f;
    }

    public void setF(double f) {
        this.f = f;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }

    public double getS() {
        return s;
    }

    public void setS(double s) {
        this.s = s;
    }

    public double getNa() {
        return na;
    }

    public void setNa(double na) {
        this.na = na;
    }

    public double getSf() {
        return sf;
    }

    public void setSf(double sf) {
        this.sf = sf;
    }
}