package com.jeommechu.web.menulist;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

import com.jeommechu.menu.lunch.LunchDAO;
import com.jeommechu.menu.lunch.LunchVO;

@WebServlet("/menuSelect")
public class MenuSelectServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private LunchDAO lunchDAO = new LunchDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String foodlistNum = request.getParameter("num");
        Integer memberId = (Integer) session.getAttribute("memberId");

        // Validate parameters
        if (foodlistNum != null && !foodlistNum.trim().isEmpty() && memberId != null) {
            LunchVO lunch = new LunchVO();
            lunch.setFoodlistNum(foodlistNum);
            lunch.setMemberId(memberId);

            try {
                boolean result = lunchDAO.addLunch(lunch);
                if (result) {
                    // 성공 시 getLunches 서블릿으로 리다이렉트
                    response.sendRedirect("getLunches");
                } else {
                    // 실패 시 menuList 서블릿으로 리다이렉트
                    response.sendRedirect("menuList?error=saveFailed");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                // 실패 시 에러 정보를 쿼리 파라미터로 추가하여 menuList 서블릿으로 리다이렉트
                response.sendRedirect("menuList?error=databaseError");
            }
        } else {
            // 파라미터가 없거나 세션 정보가 없을 경우 menuList 서블릿으로 리다이렉트
            response.sendRedirect("menuList?error=invalidInput");
        }
    }

}
